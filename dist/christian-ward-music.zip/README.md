# Christian Ward Music

## Deployment Instructions for Netlify

### Option 1: Deploy Frontend Only

1. Extract this ZIP file
2. Log in to Netlify and click "New site from Git"
3. Connect to your Git repository
4. Set Build command: `cd client && npm run build`
5. Set Publish directory: `client/dist`
6. Click "Deploy site"

### Option 2: Deploy Full Stack (Frontend + API)

1. Extract this ZIP file
2. Log in to Netlify and click "New site from Git"
3. Connect to your Git repository
4. The netlify.toml file will handle the configuration
5. Click "Deploy site"
6. Go to Site settings > Functions > Set directory to "netlify/functions"

## Adding New Tracks

To add new tracks without code changes:

1. Go to Netlify site settings > Functions
2. Use the admin interface at yourdomain.netlify.app/admin
3. Log in with the default admin credentials:
   - Username: admin
   - Password: admin123

## File Structure

- `client/`: Frontend React application
- `server/`: Backend Express API
- `shared/`: Shared types and schemas
- `uploads/`: Music track files
- `netlify/functions/`: Serverless functions for Netlify deployment
